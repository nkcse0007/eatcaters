export interface Solution {
    title: string;
    description: string;
    detail: string;
  }
  
  export interface GoogleObj {
    q: string[];
    target: string;
  }