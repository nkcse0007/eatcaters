import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-jeddah',
  templateUrl: './admin-jeddah.component.html',
  styleUrls: ['./admin-jeddah.component.css']
})
export class AdminJeddahComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
