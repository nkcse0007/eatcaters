import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-riyadh',
  templateUrl: './admin-riyadh.component.html',
  styleUrls: ['./admin-riyadh.component.css']
})
export class AdminRiyadhComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
