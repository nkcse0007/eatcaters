import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appimage',
  templateUrl: './appimage.component.html',
  styleUrls: ['./appimage.component.css']
})
export class AppimageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
