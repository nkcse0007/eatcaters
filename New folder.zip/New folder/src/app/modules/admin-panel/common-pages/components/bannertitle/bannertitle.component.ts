import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bannertitle',
  templateUrl: './bannertitle.component.html',
  styleUrls: ['./bannertitle.component.css']
})
export class BannertitleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
