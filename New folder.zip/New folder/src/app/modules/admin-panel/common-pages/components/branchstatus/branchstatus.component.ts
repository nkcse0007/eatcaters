import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branchstatus',
  templateUrl: './branchstatus.component.html',
  styleUrls: ['./branchstatus.component.css']
})
export class BranchstatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
