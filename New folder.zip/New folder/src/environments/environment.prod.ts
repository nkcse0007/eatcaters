export const environment = {
  production: true,
  BASE_URL: 'http://api.volu.relinns.website/'

};
