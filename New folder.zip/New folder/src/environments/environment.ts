
export const environment = {
  production: false,
  BASE_URL: 'http://api.dietcater.com/'

};

import 'zone.js/dist/zone-error';
