import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  LOGIN_URL = 'api/auth/login/';
  currentUser: any;

  private currentUserSubject;
  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }

  updateUserValue(data) {

    const elem = { ...JSON.parse(localStorage.getItem('currentUser')), ...data };
    localStorage.setItem('currentUser', JSON.stringify(elem));
    this.currentUserSubject.next(elem);
  }

  isLogin(): boolean {
    if (localStorage.getItem('currentUser')) {
      return true;
    }
    return false;
  }

  login(body) {
    return this.http.post<any>(environment.BASE_URL + this.LOGIN_URL, body)
      .pipe(map(user => {
        if (user && user.status && user.data.token) {
          localStorage.setItem('currentUser', JSON.stringify(user.data));
          this.currentUserSubject.next(user.data);
        }
        return user;
      }));
  }

  logout() {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }
}
