import { Injectable } from '@angular/core';
import {HttpClient,HttpErrorResponse } from '@angular/common/http';
import {environment} from '../../environments/environment';  
@Injectable({
  providedIn: 'root'
})
export class WebsiteserviceService { 
  baseUrl=environment.BASE_URL
  constructor(private http:HttpClient) { }

getTermCondition(){
  return this.http.get(this.baseUrl+'customerlist.json?key=7194e520');
}
  
}
