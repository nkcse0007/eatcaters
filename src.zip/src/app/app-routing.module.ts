import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router'; 


const routes: Routes = [  
  {
    path: '',
    loadChildren: () => import('./modules/website/website.module').then(module => module.WebsiteModule)
  },
  {path:'admin',
   loadChildren:()=> import('./modules/admin-panel/auth/auth.module').then(module=>module.AuthModule)
},
{path:'admin/pages',loadChildren:()=> import('./modules/admin-panel/common-pages/common-pages.module').then(module=>module.CommonPagesModule)}

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    enableTracing: false,
    scrollPositionRestoration:'top'
 })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
