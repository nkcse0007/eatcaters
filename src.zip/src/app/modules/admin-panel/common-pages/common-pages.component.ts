import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-pages',
  templateUrl: './common-pages.component.html',
  styleUrls: ['./common-pages.component.css']
})
export class CommonPagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
