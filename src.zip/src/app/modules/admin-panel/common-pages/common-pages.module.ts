import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommonPagesRoutingModule } from './common-pages-routing.module';
import { TermsAndUseComponent } from './components/terms-and-use/terms-and-use.component';
import { AdminPrivacyPolicyComponent } from './components/admin-privacy-policy/admin-privacy-policy.component';
import { CommonPagesComponent } from './common-pages.component';
import {SharedModule} from '../../shared/shared.module';
import { AdminCareersComponent } from './components/admin-careers/admin-careers.component';
import { AdminFaqComponent } from './components/admin-faq/admin-faq.component';
import { AdminAboutUsComponent } from './components/admin-about-us/admin-about-us.component';
import { AdminDammamComponent } from './components/admin-dammam/admin-dammam.component';
import { AdminJeddahComponent } from './components/admin-jeddah/admin-jeddah.component';
import { AdminRiyadhComponent } from './components/admin-riyadh/admin-riyadh.component';

@NgModule({
  declarations: [TermsAndUseComponent, AdminPrivacyPolicyComponent, CommonPagesComponent, AdminCareersComponent, AdminFaqComponent, AdminAboutUsComponent, AdminDammamComponent, AdminJeddahComponent, AdminRiyadhComponent],
  imports: [
    CommonModule,
    CommonPagesRoutingModule,SharedModule
  ]
})
export class CommonPagesModule { }
