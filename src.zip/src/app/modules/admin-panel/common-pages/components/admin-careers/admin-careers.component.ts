import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-careers',
  templateUrl: './admin-careers.component.html',
  styleUrls: ['./admin-careers.component.css']
})
export class AdminCareersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
