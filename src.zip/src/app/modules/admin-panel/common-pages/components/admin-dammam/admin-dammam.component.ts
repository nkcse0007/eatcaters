import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-dammam',
  templateUrl: './admin-dammam.component.html',
  styleUrls: ['./admin-dammam.component.css']
})
export class AdminDammamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
