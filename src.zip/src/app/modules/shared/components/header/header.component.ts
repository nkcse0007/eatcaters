import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router'; 
declare var $:any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit { 
  currentUrl:any;
  constructor(private route: ActivatedRoute,private router : Router) { 
}  
hideMenu(){
  $('.navbar-collapse').removeClass('show');
}
  ngOnInit() {
    
    this.currentUrl = this.router.url;
    console.log(this.currentUrl); 
    // this.solution.getSolution().subscribe(res => this.data = res);
    // this.translateBtn = document.getElementById('translatebtn');
  }
  // data: Solution = {
  //   title: '',
  //   description: '',
  //   detail: ''
  // }; 
  // send(event) {
  //   const googleObj: GoogleObj = {
  //     q: [this.data.title, this.data.description, this.data.detail],
  //     target: event
  //   };

  //   this.translateBtn.disabled = true;

  //   this.google.translate(googleObj).subscribe(
  //     (res: any) => {
  //       this.translateBtn.disabled = false;
  //       this.data = {
  //         title: res.data.translations[0].translatedText,
  //         description: res.data.translations[1].translatedText,
  //         detail: res.data.translations[2].translatedText
  //       };
  //       console.log(this.data);
  //     },
  //     err => {
  //       console.log(err);
  //     }
  //   );
  // }
}
