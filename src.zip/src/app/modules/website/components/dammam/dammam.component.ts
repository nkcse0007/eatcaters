import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dammam',
  templateUrl: './dammam.component.html',
  styleUrls: ['./dammam.component.css']
})
export class DammamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
