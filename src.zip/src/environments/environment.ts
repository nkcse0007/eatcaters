
export const environment = {
  production: false,
  BASE_URL: 'https://my.api.mockaroo.com/'

};

import 'zone.js/dist/zone-error';
